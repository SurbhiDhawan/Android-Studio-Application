package com.test.project;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class PayActivity extends Activity implements View.OnClickListener {

    private EditText etHourlyWage,etRegularHour,etOverTimeHour;
    private TextView tvResult;
    private Button btnResult;
    double weeklyPay=0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay);

        etHourlyWage=findViewById(R.id.etHourlyWage);
        etRegularHour=findViewById(R.id.etRegularHour);
        etOverTimeHour=findViewById(R.id.etOverTimeHour);

        btnResult=findViewById(R.id.btnResult);
        btnResult.setOnClickListener(this);
        tvResult=findViewById(R.id.tvResult);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onClick(View v) {
        if (v.getId()==R.id.btnResult){
            try {
                //Null pointer checks
                if (!TextUtils.isEmpty(etHourlyWage.getText().toString().trim())
                        &&!TextUtils.isEmpty(etRegularHour.getText().toString().trim())
                        &&!TextUtils.isEmpty(etOverTimeHour.getText().toString().trim())) {
                    int hourlyWage=Integer.parseInt(etHourlyWage.getText().toString().trim());
                    int regularHour=Integer.parseInt(etRegularHour.getText().toString().trim());
                    int overTimeHour=Integer.parseInt(etOverTimeHour.getText().toString().trim());

                    weeklyPay = /*7**/((hourlyWage*regularHour)+(1.5*overTimeHour*hourlyWage));

                    /* If none sides are equal */
                    tvResult.setVisibility(View.VISIBLE);
                    tvResult.setText("Employee’s total weekly pay = "+weeklyPay);
                }else {
                    tvResult.setVisibility(View.GONE);
                    Toast.makeText(this, " All field's are mandatory ", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
    }
}
