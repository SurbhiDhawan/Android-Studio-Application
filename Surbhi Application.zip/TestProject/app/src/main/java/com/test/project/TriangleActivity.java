package com.test.project;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class TriangleActivity extends Activity implements View.OnClickListener {

    private EditText etFirstLength, etSecondLength, etThirdLength;
    private TextView tvResult;
    private Button btnResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_angel);
        etFirstLength =findViewById(R.id.etFirstLength);
        etSecondLength =findViewById(R.id.etSecondLength);
        etThirdLength =findViewById(R.id.etThirdLength);

        btnResult =findViewById(R.id.btnResult);
        btnResult.setOnClickListener(this);
        tvResult=findViewById(R.id.tvResult);

    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onClick(View v) {
        if (v.getId()==R.id.btnResult){
            try {
                //Null pointer checks
                if (!TextUtils.isEmpty(etFirstLength.getText().toString().trim())
                        &&!TextUtils.isEmpty(etSecondLength.getText().toString().trim())
                        &&!TextUtils.isEmpty(etThirdLength.getText().toString().trim())){

                    int firstSide= Integer.parseInt(etFirstLength.getText().toString().trim());
                    int secondSide= Integer.parseInt(etSecondLength.getText().toString().trim());
                    int thirdSide= Integer.parseInt(etThirdLength.getText().toString().trim());

                    if(firstSide==secondSide && secondSide==thirdSide) {
                        /* If all sides are equal */
                        tvResult.setVisibility(View.VISIBLE);
                        tvResult.setText("Equilateral triangle.");
                    }
                    else if(firstSide==secondSide || firstSide==thirdSide || secondSide==thirdSide) {
                        /* If any two sides are equal */
                        tvResult.setVisibility(View.VISIBLE);
                        tvResult.setText("Isosceles triangle.");
                    }
                    else {
                        /* If none sides are equal */
                        tvResult.setVisibility(View.VISIBLE);
                        tvResult.setText("Scalene triangle.");
                    }
                }else {
                    tvResult.setVisibility(View.GONE);
                    Toast.makeText(this, " All fields are mandatory ", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }

    }
}
